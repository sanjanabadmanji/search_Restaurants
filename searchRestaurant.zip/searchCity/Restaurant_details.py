import json
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.microsoft import EdgeChromiumDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

#<----------Function to get top restaurants in a city---------->
def get_top_restaurants(city):
    search_query = f"top restaurants in {city}" # Search query for Google Maps
    url = f"https://www.google.com/maps/search/{search_query.replace(' ', '+')}/"
    
    #Initialize WebDriver for Edge
    driver = webdriver.Edge(service=Service(EdgeChromiumDriverManager().install())) # Install Edge driver
    driver.get(url) # Open the URL
    driver.maximize_window() # Maximize window to load all elements
    driver.implicitly_wait(7) # Wait for the page to load
    
    restaurants = {} # dict to store restaurant details
    
    # Wait for the container to load
    scrollable_div = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, "(//div[contains(@class, 'm6QErb DxyBCb kA9KIf')])[2]"))
    )

    # Scroll inside the container multiple times to load more results
    for _ in range(3):
        driver.execute_script("arguments[0].scrollTop += 1200;", scrollable_div) # Scroll down
        driver.implicitly_wait(4)  # Allow content to load
    
    # Get restaurant elements
    restaurant_cards = driver.find_elements(By.XPATH, "//div[@class='Nv2PK THOPZb CpccDe ']")   # Find all restaurant cards
    print(f"Total restaurants found: {len(restaurant_cards)}") # Print total restaurants found
    
    #<----------Extract restaurant details---------->
    for card in restaurant_cards[:10]:  # Limit to top 10 restaurants
        try:
            name_element = card.find_element(By.XPATH, ".//div[@class='NrDZNb']").text
            rating_element = card.find_element(By.XPATH, ".//span[@class='MW4etd']").text
            reviews_element = card.find_element(By.XPATH, ".//span[@class='UY7F9']").text
            restaurants[name_element] = {"rating": rating_element, "reviews": reviews_element}

            print(f"name_element: {name_element}, rating_element: {rating_element}, reviews_element: {reviews_element}")
                        
        except Exception as e:
            print(f"Skipping restaurant due to error: {e}")
            continue  # Skip if any data is missing

    driver.quit()
    return restaurants 

 #<----------Function to save data to JSON file---------->
def save_to_json(data, city): 
    directory = r"C:\Users\sanjana\searchCity" # Directory to save JSON file
    if not os.path.exists(directory): # Create directory if it doesn't exist
        os.makedirs(directory) 

    file_path = os.path.join(directory, f"{city.replace(' ', '_')}_restaurants.json") # File path to save data

    with open(file_path, "w", encoding="utf-8") as file: # Write data to JSON file
        json.dump(data, file, indent=4, ensure_ascii=False)

    print(f"Data saved to {file_path}") # Print success message


#<----------Main function---------->
def main(): 
    city = input("Enter the name of a city: ").strip() # Get city name from user
    restaurants = get_top_restaurants(city) # Get top restaurants in the city
    if restaurants:                         # Save data to JSON file if restaurants are found
        save_to_json(restaurants, city)    
    else:
        print("No restaurants found.")      # Print message if no restaurants are found

#<----------Run the main function---------->
if __name__ == "__main__": # Run the main function
    main()                
